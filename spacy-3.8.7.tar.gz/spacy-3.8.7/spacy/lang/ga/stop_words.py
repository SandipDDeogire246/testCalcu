STOP_WORDS = set(
    """
a ach ag agus an aon ar arna as

ba beirt bhúr

caoga ceathair ceathrar chomh chuig chun cois céad cúig cúigear

daichead dar de deich deichniúr den dhá do don dtí dá dár dó

faoi faoin faoina faoinár fara fiche

gach gan go gur

haon hocht

i iad idir in ina ins inár is

le leis lena lenár

mar mo muid mé

na nach naoi naonúr ná ní níor nó nócha

ocht ochtar ochtó os

roimh

sa seacht seachtar seachtó seasca seisear siad sibh sinn sna sé sí

tar thar thú triúr trí trína trínár tríocha tú

um

ár

é éis

í

ó ón óna ónár
""".split()
)
