"""
Example sentences to test spaCy and its language models.
>>> from spacy.lang.vi.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Đây là đâu, tôi là ai?",
    "Căn phòng có nhiều cửa sổ nên nó khá sáng",
    "Đại dịch COVID vừa qua đã gây ảnh hưởng rất lớn tới nhiều doanh nghiệp lớn nhỏ.",
    "Thành phố Hồ Chí Minh đã bị ảnh hưởng nặng nề trong thời gian vừa qua.",
    "Ông bạn đang ở đâu thế?",
    "Ai là người giải phóng đất nước Việt Nam khỏi ách đô hộ?",
    "Vị tướng nào là người đã làm nên chiến thắng lịch sử Điện Biên Phủ?",
    "Làm việc nhiều chán quá, đi chơi đâu đi?",
]
